import brain
import brainlab
import brainsim
import numpy
from numpy import pi
import scipy
from matplotlib import pyplot

# for external use
def genSpikePlotXY(prefix, num):
	listX = brainsim.loadBrain(prefix + str(num) + '-XReport.txt')
	listY = brainsim.loadBrain(prefix + str(num) + '-YReport.txt')
	c = numpy.linspace(0.0, len(listX), len(listX), endpoint=False)
	d = numpy.linspace(0.0, len(listY), len(listY), endpoint=False)
	pyplot.subplot(211)
	pyplot.title("Neuron X")
	pyplot.plot(c,listX)
	pyplot.subplot(212)
	pyplot.title("Neuron Y")
	pyplot.plot(d,listY)
	pyplot.show()

# for in-file use
def showSpikePlotXY():
	pyplot.subplot(211)
	pyplot.title("Neuron X")
	pyplot.plot(t,A)
	pyplot.subplot(212)
	pyplot.title("Neuron Y")
	pyplot.plot(t,B)
	pyplot.show()

def showCorrPlot():
	c = numpy.linspace(0.0, len(correlations), len(correlations), endpoint=False)
	pyplot.subplot(211)
	pyplot.title("Correlation")
	pyplot.plot(c, numpy.array(correlations).astype(float), 'ro')
	pyplot.subplot(212)
	pyplot.title("Phase shift")
	pyplot.plot(c, numpy.array(phases).astype(float), 'b')
	pyplot.show()

def giveCorrelation():
	xcorr = scipy.correlate(A, B)
	return xcorr

def givePhaseShift(xcorr):
	period=1.0
	dt = numpy.linspace(-t[-1], t[-1], 2*nsamples-1)
	recovered_time_shift = dt[xcorr.argmax()]
	recovered_phase_shift = 2*pi*(((0.5 + recovered_time_shift/period) % 1.0) - 0.5)
	print 'Phase shift: ', recovered_phase_shift
	print 'Correlation: ', xcorr
	return recovered_phase_shift

correlations=[]
phases=[]
i=float(0)
trials=1000
esynval=0.0
isynval=1.0
while i < trials:
	parameters = {
	'ESYN_MAXCONDUCTANCE':0, #0.05 ['']
	'ISYN_MAXCONDUCTANCE':0, #0.4
	'CONN_LATERAL':1, #0.02
	'CONN_INTERNAL':1, #0.02
	'ENDSIM':5, 
	'FSV':10000,
	'BRAINNAME':"vb-exp1",
	'TAU_NOISE':0.020} #0.020

#	parameters['CONN_INTERNAL']=i/100
#	parameters['CONN_LATERAL']=i/100
	parameters['ESYN_MAXCONDUCTANCE']=esynval
	parameters['ISYN_MAXCONDUCTANCE']=isynval
	esynval=esynval+0.001
	isynval=isynval-0.001
#	parameters['TAU_NOISE']=(trials-i)/trials

	parameters['BRAINNAME']='vb-exp'+str(int(i))
	print parameters
	brainsim.simBrain(parameters)
	listX = brainsim.loadBrain(parameters['BRAINNAME']+'-XReport.txt')
	listY = brainsim.loadBrain(parameters['BRAINNAME']+'-YReport.txt')

	nsamples=len(listX)
	t = numpy.linspace(0.0, parameters['ENDSIM'], nsamples, endpoint=False)
	A=numpy.array(listX).astype(float)
	B=numpy.array(listY).astype(float)

	xcorr = giveCorrelation()
	correlations.append(xcorr[xcorr.argmax()])
	phases.append(givePhaseShift(xcorr))
#	showSpikePlotXY()
	i=i+1

print "Correlations:", correlations
print "Phases", phases
showCorrPlot()
